# ⛔ 채점 전 열람 금지
answers_SEALED.csv 는 test.csv 의 정답이다.
제출 파일 완성 후 루트에서 `python grade.py submission.csv` 로 자가 채점만 할 것.
미리 보면 리허설 의미가 사라진다.
