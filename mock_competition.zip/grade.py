# -*- coding: utf-8 -*-
"""자가 채점기 — python grade.py submission.csv"""
import sys
import pandas as pd
import numpy as np

sub = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else "submission.csv")
ans = pd.read_csv("채점용_봉인/answers_SEALED.csv")

m = ans.merge(sub, on="equipment_id", how="left", suffixes=("_true", "_pred"))
missing = m["label_pred"].isna().sum()
if missing:
    print(f"⚠️ 제출 누락 {missing}대 → 오답 처리")
    m["label_pred"] = m["label_pred"].fillna("__missing__")

classes = sorted(ans["label"].unique())
f1s = {}
for c in classes:
    tp = ((m.label_pred == c) & (m.label_true == c)).sum()
    fp = ((m.label_pred == c) & (m.label_true != c)).sum()
    fn = ((m.label_pred != c) & (m.label_true == c)).sum()
    f1s[c] = 2 * tp / max(2 * tp + fp + fn, 1)

print("=" * 44)
print("📊 채점 결과")
print("=" * 44)
for c, f in f1s.items():
    print(f"  {c:8s} F1 = {f:.4f}")
print("-" * 44)
print(f"  🏆 Macro F1 = {np.mean(list(f1s.values())):.4f}")
print("=" * 44)
